using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAttack : MonoBehaviour
{
    public bool isCanAttack = true;

    public Transform attackAxis;

    public int attackDamage;
    public float attackCD;

    public float attackSpeedBuff = 1.5f;
    public float currentAttackSpeedBuff = 1.0f;
    public float attackBuffDuration = 4f;

    private float knockback;

    public Transform normalAttackRange;
    public GameObject normalAttackEffect;

    public GameObject arrow;
    public bool isCharging;
    public float maxChargingTime;
    private float chargingTimer;
    public float chargingStrength;
    public int maxArrowThrough; //�ִ� ����

    public GameObject minion;

    public void Attack(int attackType, float knockback)
    {
        isCanAttack = false;
        this.knockback = knockback;

        switch (attackType)
        {
            case 0:
            case 1:
                NormalAttack(); break;

            case 2:
                BowAttack(); break;

            case 3: break;
        }
    }

    private void ReturnCanAttackState()
    {
        isCanAttack = true;
    }

    private void Update()
    {
        BowCharging();
    }

    private void NormalAttack()
    {
        Collider2D[] rangeEnemys = Physics2D.OverlapBoxAll(normalAttackRange.position, normalAttackRange.localScale, 0, LayerMask.GetMask("Enemy"));

        normalAttackEffect.SetActive(true);
        foreach (Collider2D enemy in rangeEnemys)
        {
            EnemyController enemyScript = enemy.GetComponent<EnemyController>();
            enemyScript.GetDamage(attackDamage, attackAxis.position, knockback);
        }

        Invoke(nameof(ReturnCanAttackState), attackCD / attackSpeedBuff);
    }

    private void BowAttack()
    {
        chargingTimer = 0;
        isCharging = true;
    }

    private void BowCharging()
    {
        if (isCharging)
        {
            chargingStrength = 1 - (maxChargingTime - chargingTimer) / maxChargingTime;
            chargingTimer += Time.deltaTime;
            chargingTimer = Mathf.Min(chargingTimer, maxChargingTime);

            if (Input.GetKeyUp(KeyCode.Mouse0))
            {
                isCharging = false;

                Arrow arrow = Instantiate(this.arrow, transform.position, attackAxis.rotation, GamePlayManager.instance.InstantiateObjectParent)
                    .GetComponent<Arrow>();

                arrow.damage = (int)Mathf.Round(attackDamage * chargingStrength);
                arrow.knockback = knockback * chargingStrength;
                arrow.speed *= chargingStrength;
                arrow.maxThroughEnemy = maxArrowThrough;

                Invoke(nameof(ReturnCanAttackState), attackCD / attackSpeedBuff);
            }
        }
    }

    public void SummonMinion()
    {
        Instantiate(minion, transform.position, Quaternion.identity, transform);
    }
}
