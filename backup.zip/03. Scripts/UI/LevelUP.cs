using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LevelUP : MonoBehaviour
{
    private Animator anim;

    private CanvasGroup canvasGroup;
    private CanvasGroupSetting canvasGroupSetting;

    public Text alertMessage;

    public GameObject[] selectAttacks;

    public void Start()
    {
        transform.localPosition = Vector3.zero;
        anim = GetComponent<Animator>();
        canvasGroup = GetComponent<CanvasGroup>();
        canvasGroupSetting = GetComponent<CanvasGroupSetting>();

        int level = GamePlayManager.instance.player.level;
        int index = GamePlayManager.instance.player.attackType;

        if (level <= 2)
            ActiveSelect(selectAttacks[0]);
        else
            ActiveSelect(selectAttacks[index + 1]);
    }


    private void ActiveSelect(GameObject select)
    {
        foreach(GameObject obj in selectAttacks)
            obj.SetActive(false);

        select.SetActive(true);
    }

    public void SelectAttack()
    {
        anim.SetTrigger("AttackSelected");
        canvasGroup.interactable = false;
    }

    public void EndAnim()
    {
        canvasGroup.interactable = true;
    }

    public void SelectSkill()
    {
        canvasGroupSetting.Alpha1to0(1, () =>
        {
            GamePlayManager.instance.isPause = false;
            Destroy(gameObject);
        });
    }
}
