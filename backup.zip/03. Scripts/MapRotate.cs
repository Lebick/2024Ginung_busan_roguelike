using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.U2D;
using System.Linq;

public class MapRotate : MonoBehaviour
{
    public SpriteShapeController spriteShapeController;

    private List<Vector3> pos;
    private List<float> angle;
    private Transform player;

    private float currentRotation;
    
    private void Start()
    {
        player = GamePlayManager.instance.player.transform;

        Spline spline = spriteShapeController.spline;
        int count = spline.GetPointCount();
        pos = new();
        angle = new();

        for (int i = 0; i < count; i++)
        {
            pos.Add(spline.GetPosition(i));
            angle.Add((90f / (count - 1)) * i);
        }
    }

    private void Update()
    {
        FindNearPoint();
        RotateObj();
    }

    private void FindNearPoint()
    {
        float nearestDistance = Mathf.Infinity;

        for (int i = 0; i < pos.Count; i++)
        {
            float distance = Vector3.Distance(player.position, pos[i]);

            if (distance < nearestDistance)
            {
                nearestDistance = distance;
                currentRotation = angle[i];
            }
        }
    }

    private void RotateObj()
    {
        player.localEulerAngles = Vector3.Lerp(player.localEulerAngles, new Vector3(0, 0, currentRotation), Time.deltaTime * 10f);
        foreach (EnemyController enemy in GamePlayManager.instance.enemys)
        {
            if (enemy == null) continue;

            Transform tr = enemy.transform;
            tr.localEulerAngles = Vector3.Lerp(tr.localEulerAngles, new Vector3(0, 0, currentRotation), Time.deltaTime * 10f);
        }

        GamePlayManager.instance.currentRotation = currentRotation;
    }

}
