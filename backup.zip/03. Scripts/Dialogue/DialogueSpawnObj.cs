using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DialogueSpawnObj : MonoBehaviour
{
    public void SpawnDialogue(string msg)
    {
        DialogueManager.instance.SpawnDialogue(transform, msg);
    }
}
