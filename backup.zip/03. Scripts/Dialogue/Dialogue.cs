using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Dialogue : MonoBehaviour
{
    private CanvasGroupSetting canvasGroup;

    public Text text;
    public Transform follow;
    public string msg;
    public float waitTime = 0.2f;

    public Vector3 offset;

    public void Setting(Transform follow, string msg)
    {
        this.follow = follow;
        this.msg = msg;
    }

    private void Start()
    {
        transform.SetParent(GamePlayManager.instance.cameraCanvas, false);

        canvasGroup = GetComponent<CanvasGroupSetting>();
        StartCoroutine(StartDialogue());
    }

    private void Update()
    {
        GetComponent<RectTransform>().position = follow.position + transform.up * offset.y;
    }

    private IEnumerator StartDialogue()
    {
        string currentMsg = string.Empty;
        int currentSize = 128;

        bool isColor = false;
        bool isSize = false;

        for(int i=0; i<msg.Length; i++)
        {
            switch (msg[i])
            {
                case 'q': waitTime *= 1.25f; continue;//���ӵ� 1.25x

                case 'w': waitTime *= 0.8f; continue;//���ӵ� 0.8x

                case 'a': //������
                    currentMsg += "<color=#ff6666>";
                    isColor = true;
                    continue;

                case 's': //�ʷϻ�
                    currentMsg += "<color=#66aaff>";
                    isColor = true;
                    continue;

                case 'd': //�Ķ���
                    currentMsg += "<color=#99ff99>";
                    isColor = true;
                    continue;

                case 'f': //������
                    currentMsg += "</color>";
                    isColor = false;
                    continue;

                case 'z': //ũ�� 1.25x
                    if (isSize)
                        currentMsg += "</size>";

                    currentSize = (int)(currentSize * 1.25f);
                    currentMsg += $"<size={currentSize}>";
                    isSize = true;
                    continue;

                case 'x': //ũ�� 0.8x
                    if (isSize)
                        currentMsg += "</size>";

                    currentSize = (int)(currentSize * 0.8f);
                    currentMsg += $"<size={currentSize}>";
                    isSize = true;
                    continue;
            }
            currentMsg += msg[i];

            text.text = currentMsg + (isColor ? "</color>" : "") + (isSize ? "</size>" : "");

            yield return new WaitForSeconds(waitTime);
        }

        yield return new WaitForSeconds(0.5f);
        canvasGroup.Alpha1to0(0.5f);
    }
}
