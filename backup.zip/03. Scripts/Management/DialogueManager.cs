using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DialogueManager : Singleton<DialogueManager>
{
    public Dialogue dialogue;
    private Transform canvas;

    private void Start()
    {
        canvas = GamePlayManager.instance.cameraCanvas;
    }

    public void SpawnDialogue(Transform follow, string msg)
    {
        Dialogue newDialogue = Instantiate(dialogue, follow.position, Quaternion.identity);
        newDialogue.Setting(follow, msg);
    }
}
