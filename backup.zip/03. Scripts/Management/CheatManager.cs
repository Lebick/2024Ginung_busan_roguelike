using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CheatManager : MonoBehaviour
{
    public Transform canvas;

    public GameObject enemySelect;
    public GameObject itemSelect;

    private GameObject enemySelectInstantiate;
    private GameObject itemSelectInstantiate;

    private void Update()
    {
        for(int i=(int)KeyCode.F1; i<=(int)KeyCode.F7; i++)
        {
            if (Input.GetKeyDown((KeyCode)i))
            {
                Invoke($"Cheat{i-(int)KeyCode.F1}",0);
            }
        }
    }

    private void Cheat0()
    {
        print("�������� �̵�");
    }

    private void Cheat1()
    {
        print("���� ���");
        GamePlayManager.instance.player.LevelUP();
    }

    private void Cheat2()
    {
        print("�÷��̾� ����");
        GamePlayManager.instance.player.SetInvincibleState();
    }

    private void Cheat3()
    {
        print("ü�� | ���� Ǯ");
        GamePlayManager.instance.player.hp = GamePlayManager.instance.player.maxHP;
        GamePlayManager.instance.player.mp = GamePlayManager.instance.player.maxMP;
    }

    private void Cheat4()
    {
        print("�� ���� ����");

        if (enemySelectInstantiate == null)
            enemySelectInstantiate = Instantiate(enemySelect, canvas);
        else
            Destroy(enemySelectInstantiate);
    }

    private void Cheat5()
    {
        print("������ ���� ���");
        print("�̱���");

        if (itemSelectInstantiate == null)
            itemSelectInstantiate = Instantiate(itemSelect, canvas);
        else
            Destroy(itemSelectInstantiate);
    }

    private void Cheat6()
    {
        print("��� �� óġ");
        foreach(EnemyController enemy in GamePlayManager.instance.enemys)
        {
            enemy.ForceDeath();
        }
    }
}
