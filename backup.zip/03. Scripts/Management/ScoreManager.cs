using System.Collections;
using System.Collections.Generic;
using UnityEditor.Search;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ScoreManager : Singleton<ScoreManager>
{
    public int killScore;
    public int bossScore;
    public int levelUpScore;
    public int hpScore;
    public int mpScore;
    public int itemScore;
    public int penaltyScore;
    public int finalScore;

    private void Start()
    {
        DontDestroyOnLoad(gameObject);
    }

    private void Update()
    {
        finalScore = killScore + bossScore + levelUpScore + hpScore + mpScore + itemScore - penaltyScore;

        if (SceneManager.GetActiveScene().name == "Title")
            Reset();
    }

    private void Reset()
    {
        killScore = 0;
        bossScore = 0;
        levelUpScore = 0;
        hpScore = 0;
        mpScore = 0;
        itemScore = 0;
        penaltyScore = 0;
    }
}
