using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class GamePlayManager : Singleton<GamePlayManager>
{
    public bool isCutScene;
    public bool isPause;

    public PlayerController player;
    public List<EnemyController> enemys;

    public RectTransform overlayCanvas;
    public Transform cameraCanvas;

    public Transform InstantiateObjectParent;
    public Transform enemyParent;
    public Transform[] enemySpawnPos;

    public StageSequence stageSequence;

    public float currentRotation;

    public bool isEnemyStop;

    private void Update()
    {
        enemys = enemyParent.GetComponentsInChildren<EnemyController>().ToList();
    }

    public void SetCutSceneState(bool value)
    {
        isCutScene = value;
    }
}
